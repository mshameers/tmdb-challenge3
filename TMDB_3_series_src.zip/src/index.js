import { Launch } from 'wpe-lightning-sdk'
import App from './App.js'

export default function() {
    return Launch(App, ...arguments)
}